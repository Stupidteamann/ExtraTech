# MINECRAFT BACKDOOR PLUGIN

A Force OP/Backdoor minecraft plugin which can be used to get OP on a Minecraft server
I'm on discord too if you need any help - Momin#7755

This plugin will get updates but not frequently.

# Commands

**__momin5ontop** - Sets you as OP on the server

**__stop** - Stops the server

## How to use the plugin:

**EASY:**
Put the .jar file to the plugins folder of the server 

**MANUAL:**
If your trying to build from source then make sure to add spigot-api jar file as a depedency 
https://hub.spigotmc.org/nexus/content/repositories/snapshots/org/spigotmc/spigot-api/

## NOTICE
If you skid the plugin or edit it in any shape or form, give credit to this repository.

## THIS PLUGIN IS FOR EDUCATIONAL PURPOSES ONLY. WE ARE NOT RESPONSIBLE FOR ANY HARM DONE WITH THIS PLUGIN.
